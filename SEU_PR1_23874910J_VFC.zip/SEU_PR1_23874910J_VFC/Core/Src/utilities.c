/*
 * utilities.c
 *
 *  Created on: May 3, 2022
 *      Author: vfruc
 */

#include "main.h"
#include "utilities.h"
int turno = 0;
int contador =0;
int enciende =0;
readbut(hadc1){

	  int t;
	  int raw;



	 	  raw = HAL_ADC_GetValue(&hadc1);

	 	  if(raw<512){
	 		  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,1);
	 		 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,1);
	 		 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,1);
	 		 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,1);
	 		 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,1);
	 		 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,1);
	 		 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,1);
	 		 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,1);


	 	  }
	 	 else if (raw>512 && raw<1024){
	 		  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,1);
	 		 		 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,1);
	 		 		 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,1);
	 		 		 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,1);
	 		 		 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,1);
	 		 		 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,1);
	 		 		 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,1);
	 		 		 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);
	 	  }
	 	else if (raw>1024 && raw<1536){
	 	 		  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,1);
	 	 		 		 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,1);
	 	 		 		 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,1);
	 	 		 		 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,1);
	 	 		 		 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,1);
	 	 		 		 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,1);
	 	 		 		 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,0);
	 	 		 		 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);
	 	 	  }
	 	  else if (raw>1536 && raw<2048){
	 	  	 		  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,1);
	 	  	 		 		 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,1);
	 	  	 		 		 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,1);
	 	  	 		 		 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,1);
	 	  	 		 		 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,1);
	 	  	 		 		 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,0);
	 	  	 		 		 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,0);
	 	  	 		 		 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);
	 	  	 	  }
	 	 else if (raw>2048 && raw<2560){
	 		  	 		  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,1);
	 		  	 		 		 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,1);
	 		  	 		 		 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,1);
	 		  	 		 		 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,1);
	 		  	 		 		 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,0);
	 		  	 		 		 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,0);
	 		  	 		 		 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,0);
	 		  	 		 		 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);
	 		  	 	  }
	 	else if (raw>2560 && raw<3072){
	 		  	 		  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,1);
	 		  	 		 		 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,1);
	 		  	 		 		 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,1);
	 		  	 		 		 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,0);
	 		  	 		 		 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,0);
	 		  	 		 		 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,0);
	 		  	 		 		 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,0);
	 		  	 		 		 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);
	 		  	 	  }
	 	else if (raw>3072 && raw<3584){
	 	 		  	 		  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,1);
	 	 		  	 		 		 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,1);
	 	 		  	 		 		 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,0);
	 	 		  	 		 		 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,0);
	 	 		  	 		 		 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,0);
	 	 		  	 		 		 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,0);
	 	 		  	 		 		 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,0);
	 	 		  	 		 		 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);
	 	 		  	 	  }
	 	else if (raw>3584 && raw<4096){
	 	 	 		  	 		  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,1);
	 	 	 		  	 		 		 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,0);
	 	 	 		  	 		 		 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,0);
	 	 	 		  	 		 		 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,0);
	 	 	 		  	 		 		 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,0);
	 	 	 		  	 		 		 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,0);
	 	 	 		  	 		 		 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,0);
	 	 	 		  	 		 		 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);
	 	 	 		  	 	  }
	 	  return raw;


  }
 readbut2(hadc1){

	 int ra;float VR;
		  float RN;
		  float TN;
		  	  int R25=10000;int T25=298;int BETA=3900;

		  	  	  	ra = HAL_ADC_GetValue(&hadc1);
		  	  	  	     VR=(ra/4095.0)*3.3;

		  	  	  	     RN=(10000.0*3.3/(3.3-VR))-10000.0;
		  	  	  	     TN=BETA/(log(RN/R25)+BETA/T25)-273.18;




		  	  	  	 if(TN<=25){
		  	  	  		  	  			  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,1);
		  	  	  		  	  			 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,0);
		  	  	  		  	  			 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,0);
		  	  	  		  	  			 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,0);
		  	  	  		  	  			 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,0);
		  	  	  		  	  			 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,0);
		  	  	  		  	  			 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,0);
		  	  	  		  	  			 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);



		  	  	  		  	  		  }
		  	  	  		  	  		  else if (TN>25 && TN<25.9){
		  	  	  		  	  			  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,1);
		  	  	  		  	  			 		 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,1);
		  	  	  		  	  			 		 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,0);
		  	  	  		  	  			 		 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,0);
		  	  	  		  	  			 		 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,0);
		  	  	  		  	  			 		 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,0);
		  	  	  		  	  			 		 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,0);
		  	  	  		  	  			 		 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);

		  	  	  		  	  		  }
		  	  	  		  	  		  else if (TN>26 && TN<26.9){
		  	  	  		  	  		 		  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,1);
		  	  	  		  	  		 		 		 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,1);
		  	  	  		  	  		 		 		 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,1);
		  	  	  		  	  		 		 		 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,0);
		  	  	  		  	  		 		 		 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,0);
		  	  	  		  	  		 		 		 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,0);
		  	  	  		  	  		 		 		 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,0);
		  	  	  		  	  		 		 		 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);

		  	  	  		  	  		 	  }
		  	  	  		  	  		  else if (TN>27 && TN<27.9){
		  	  	  		  	  		  	 		  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,1);
		  	  	  		  	  		  	 		 		 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,1);
		  	  	  		  	  		  	 		 		 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,1);
		  	  	  		  	  		  	 		 		 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,1);
		  	  	  		  	  		  	 		 		 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,0);
		  	  	  		  	  		  	 		 		 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,0);
		  	  	  		  	  		  	 		 		 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,0);
		  	  	  		  	  		  	 		 		 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);

		  	  	  		  	  		  	 	  }
		  	  	  		  	  		  else if (TN>28 && TN<28.9){
		  	  	  		  	  			  	 		  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,1);
		  	  	  		  	  			  	 		 		 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,1);
		  	  	  		  	  			  	 		 		 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,1);
		  	  	  		  	  			  	 		 		 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,1);
		  	  	  		  	  			  	 		 		 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,1);
		  	  	  		  	  			  	 		 		 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,0);
		  	  	  		  	  			  	 		 		 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,0);
		  	  	  		  	  			  	 		 		 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);


		  	  	  		  	  			  	 	  }
		  	  	  		  	  		  else if (TN>29 && TN<29.9){
		  	  	  		  	  			  	 		  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,1);
		  	  	  		  	  			  	 		 		 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,1);
		  	  	  		  	  			  	 		 		 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,1);
		  	  	  		  	  			  	 		 		 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,1);
		  	  	  		  	  			  	 		 		 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,1);
		  	  	  		  	  			  	 		 		 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,1);
		  	  	  		  	  			  	 		 		 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,0);
		  	  	  		  	  			  	 		 		 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);

		  	  	  		  	  			  	 	  }
		  	  	  		  	  		  else if (TN>30 && TN<30.9){
		  	  	  		  	  		 		  	 		  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,1);
		  	  	  		  	  		 		  	 		 		 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,1);
		  	  	  		  	  		 		  	 		 		 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,1);
		  	  	  		  	  		 		  	 		 		 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,1);
		  	  	  		  	  		 		  	 		 		 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,1);
		  	  	  		  	  		 		  	 		 		 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,1);
		  	  	  		  	  		 		  	 		 		 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,1);
		  	  	  		  	  		 		  	 		 		 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);

		  	  	  		  	  		 		  	 	  }
		  	  	  		  	  		  else if (TN>31 ){
		  	  	  		  	  		 	 		  	 		  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,1);
		  	  	  		  	  		 	 		  	 		 		 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,1);
		  	  	  		  	  		 	 		  	 		 		 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,1);
		  	  	  		  	  		 	 		  	 		 		 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,1);
		  	  	  		  	  		 	 		  	 		 		 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,1);
		  	  	  		  	  		 	 		  	 		 		 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,1);
		  	  	  		  	  		 	 		  	 		 		 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,1);
		  	  	  		  	  		 	 		  	 		 		 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,1);

		  	  	  		  	  		 	 		  	 	  }

return ra;
}
readbut3(hadc1){
	int raws;

if(contador-turno>=1500){
	enciende = !enciende;
	turno = contador;

}
raws = HAL_ADC_GetValue(&hadc1);
if(raws<512){
	  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,enciende);

		  	  			 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,0);
		  	  			 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,0);
		  	  			 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,0);
		  	  			 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,0);
		  	  			 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,0);
		  	  			 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,0);
		  	  			 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);


	  		  }
	  		  else if (raws>512 && raws<1024){
	  			  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,0);

	  				  	  			 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);
	  			  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,enciende);
	  		  }
	  		  else if (raws>1024 && raws<1536){
	  			  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,enciende);
	  			  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,0);

	  				  	  			 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);
	  		 	  }
	  		  else if (raws>1536 && raws<2048){
	  			  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,enciende);
	  			  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,0);

	  				  	  			 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);
	  		  	 	  }
	  		  else if (raws>2048 && raws<2560){
	  			  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,enciende);
	  			  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,0);

	  				  	  			 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);

	  			  	 	  }
	  		  else if (raws>2560 && raws<3072){
	  			  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,enciende);
	  			  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,0);

	  				  	  			 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);
	  			  	 	  }
	  		  else if (raws>3072 && raws<3584){
	  			  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,enciende);
	  			  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,0);
	  				  	  			 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,0);

	  				  	  			 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,0);
	  		 		  	 	  }
	  		  else if (raws>3584 && raws<4096){

	  		 	 		  	 		 		 	  HAL_GPIO_WritePin(D8_GPIO_Port,D8_Pin,enciende);
	  		 	 		  	 		 	  HAL_GPIO_WritePin(D1_GPIO_Port,D1_Pin,0);
	  		 	 		  	 		 		  	  			 	  HAL_GPIO_WritePin(D2_GPIO_Port,D2_Pin,0);
	  		 	 		  	 		 		  	  			 	  HAL_GPIO_WritePin(D3_GPIO_Port,D3_Pin,0);
	  		 	 		  	 		 		  	  			 	  HAL_GPIO_WritePin(D4_GPIO_Port,D4_Pin,0);
	  		 	 		  	 		 		  	  			 	  HAL_GPIO_WritePin(D5_GPIO_Port,D5_Pin,0);
	  		 	 		  	 		 		  	  			 	  HAL_GPIO_WritePin(D6_GPIO_Port,D6_Pin,0);
	  		 	 		  	 		 		  	  			 	  HAL_GPIO_WritePin(D7_GPIO_Port,D7_Pin,0);


	  		 	 		  	 	  }
contador++;
return raws;

}



