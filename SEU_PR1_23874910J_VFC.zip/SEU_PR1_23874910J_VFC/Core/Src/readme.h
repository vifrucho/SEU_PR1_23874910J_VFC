/*
 * readme.h
 *
 *  Created on: 11 may. 2022
 *      Author: vfruc
 *
 *
 *
 * El código comienza recogiendo el valor del potenciometro y almacenándolo en una variable.
 *
 * Después según el valor de un contador y si hemos pulsado o no el botón izquierdo seleccionamos un canal u otro que podemos cambiar utilizando el botón antes mencionado.
 *
 * El código es parecido para los dos casos: Si seleccionamos el fotoreceptor llamaremos a readbut cuya función recogerá el valor del sensor y calcular cuantos leds debemos encender o apagar.
 * Luego devolvemos el valor conseguido con el cual si vemos que sobrepasa el valor del potenciometro, se activará el buzzer que se detendra si apretamos el botón derecho,bloqueará la activación del buzzer
 * e iniciará un contador que cuando pasen 10s volverá a permitir la comparación de valores entre potenciometro y sensor. El codigo del NTC será practicamente idéntico.
 *
 */


