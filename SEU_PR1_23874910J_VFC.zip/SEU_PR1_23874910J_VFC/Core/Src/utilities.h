/*
 * utilities.h
 *
 *  Created on: May 3, 2022
 *      Author: vfruc
 */

#ifndef SRC_UTILITIES_H_
#define SRC_UTILITIES_H_

readbut(hadc1);
readbut2(hadc1);
readbut3(hadc1);


#endif /* SRC_UTILITIES_H_ */
